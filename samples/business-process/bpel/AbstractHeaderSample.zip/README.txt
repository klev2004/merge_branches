
This sample discuss on how to pass values through header in a bpel process. Sample is about a module enrollment process,
where the courseId is passed in the header of the request and other details (name,age etc) are passed in the body of the request.