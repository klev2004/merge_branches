This sample demonstrates how to alter the content of a response given a request.
When the customer provides SSN value, the response will contain a default credit rating property as well in the response.
