1. Log in into BPS server management console and select "Processes -> Add" under the "Main" menu.
2. Upload the While.zip found in the EI_Home/wso2/business-process/samples/business-process/bpel directory.
3. In the "Deployed Processes" window, click the "Process ID" to access its "Process Information" window.
4. Under the "WSDL Details" widget, trigger the process using the "TryIt" link to create an instance of it.